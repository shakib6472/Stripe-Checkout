<section class="popup-loading-wrapper" id="proc_popup" style="display:none">
                <div class="popup"> <img alt="" class="lock-image"
                        src="https://tryactiveketop.com/static/common/images/a42ef94e3b7c048526248b10dc7dec0b.png" />
                    <p>Please wait a moment</p>
                    <h3>Your Order is Now Being Processed</h3> <img alt="" class="loading-image"
                        src="https://tryactiveketop.com/static/common/images/66abd1ae20dbaf850feb0e0c3eab87b8.png" />
                </div>
            </section>
            <section class="custom-social-proof">
                <div class="custom-notification">
                    <div class="custom-notification-container">
                        <div class="custom-notification-image-wrapper"> <img
                                src="https://tryactiveketop.com/static/activeketo_gummies/intl-v1/desktop/images/8d9846a37b97ea988730472b9e68998e.png" />
                        </div>
                        <div class="custom-notification-content-wrapper">
                            <p class="custom-notification-content"> <span id="notify-customer">Eli H</span>. - <span
                                    id="notify-state">TX</span><br /> Purchased <strong><span
                                        id="notify-quantity">7</span></strong> Bottle(s) of Active KETO Gummies <small><span
                                        id="notify-ago">9 minutes ago</span></small> </p>
                        </div>
                    </div>
                    <div class="custom-close"></div>
                </div>
            </section>