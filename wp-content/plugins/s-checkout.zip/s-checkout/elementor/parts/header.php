<header class="header">
                <div class="container header__block row"> <img alt="" class="header__logo"
                        src="<?php echo plugins_url('img/logo.png', __FILE__); ?>" height="53" />
                    <div class="header__info">
                        <img alt="" src="<?php echo plugins_url('/img/canada.png', __FILE__); ?>" class="dynamicFlag" width="61"
                            height="40" />
                        <img alt="" src="<?php echo plugins_url('/img/usa.png', __FILE__); ?>" class="dynamicFlag" width="61"
                            height="40" />
                    </div>
                </div>
            </header>